package transaction_test

import (
	"encoding/hex"
	"testing"

	script "github.com/bsv-blockchain/go-sdk/script"
	"github.com/bsv-blockchain/go-sdk/transaction"
	sighash "github.com/bsv-blockchain/go-sdk/transaction/sighash"
	"github.com/stretchr/testify/require"
)

func TestTx_CalcInputPreimage(t *testing.T) {
	t.Parallel()

	var testVector = []struct {
		name               string
		unsignedTx         string
		index              int
		previousTxSatoshis uint64
		SourceTxScript     string
		sigHashType        sighash.Flag
		expectedPreimage   string
	}{
		{
			"1 Input 2 Outputs - SIGHASH_ALL (FORKID)",
			"010000000193a35408b6068499e0d5abd799d3e827d9bfe70c9b75ebe209c91d25072326510000000000ffffffff02404b4c00000000001976a91404ff367be719efa79d76e4416ffb072cd53b208888acde94a905000000001976a91404d03f746652cfcb6cb55119ab473a045137d26588ac00000000",
			0,
			100000000,
			"76a914c0a3c167a28cabb9fbb495affa0761e6e74ac60d88ac",
			sighash.AllForkID,
			"010000007ced5b2e5cf3ea407b005d8b18c393b6256ea2429b6ff409983e10adc61d0ae83bb13029ce7b1f559ef5e747fcac439f1455a2ec7c5f09b72290795e7066504493a35408b6068499e0d5abd799d3e827d9bfe70c9b75ebe209c91d2507232651000000001976a914c0a3c167a28cabb9fbb495affa0761e6e74ac60d88ac00e1f50500000000ffffffff87841ab2b7a4133af2c58256edb7c3c9edca765a852ebe2d0dc962604a30f1030000000041000000",
		},
		{
			"2 Inputs 3 Outputs - SIGHASH_ALL (FORKID) - Index 0",
			"01000000027e2705da59f7112c7337d79840b56fff582b8f3a0e9df8eb19e282377bebb1bc0100000000ffffffffdebe6fe5ad8e9220a10fcf6340f7fca660d87aeedf0f74a142fba6de1f68d8490000000000ffffffff0300e1f505000000001976a9142987362cf0d21193ce7e7055824baac1ee245d0d88ac00e1f505000000001976a9143ca26faa390248b7a7ac45be53b0e4004ad7952688ac34657fe2000000001976a914eb0bd5edba389198e73f8efabddfc61666969ff788ac00000000",
			0,
			2000000000,
			"76a914eb0bd5edba389198e73f8efabddfc61666969ff788ac",
			sighash.AllForkID,
			"01000000eaef7a1b82f72f4097e63b0173906d690cc137221d221fc4150bae88570fa356752adad0a7b9ceca853768aebb6965eca126a62965f698a0c1bc43d83db632ad7e2705da59f7112c7337d79840b56fff582b8f3a0e9df8eb19e282377bebb1bc010000001976a914eb0bd5edba389198e73f8efabddfc61666969ff788ac0094357700000000ffffffff0cf3246582f4b1b5fd150b942916c7d5c78e80259cbab1a761a9e4ac3a66e0a70000000041000000",
		},
		{
			"2 Inputs 3 Outputs - SIGHASH_ALL (FORKID) - Index 1",
			"01000000027e2705da59f7112c7337d79840b56fff582b8f3a0e9df8eb19e282377bebb1bc0100000000ffffffffdebe6fe5ad8e9220a10fcf6340f7fca660d87aeedf0f74a142fba6de1f68d8490000000000ffffffff0300e1f505000000001976a9142987362cf0d21193ce7e7055824baac1ee245d0d88ac00e1f505000000001976a9143ca26faa390248b7a7ac45be53b0e4004ad7952688ac34657fe2000000001976a914eb0bd5edba389198e73f8efabddfc61666969ff788ac00000000",
			1,
			2000000000,
			"76a914eb0bd5edba389198e73f8efabddfc61666969ff788ac",
			sighash.AllForkID,
			"01000000eaef7a1b82f72f4097e63b0173906d690cc137221d221fc4150bae88570fa356752adad0a7b9ceca853768aebb6965eca126a62965f698a0c1bc43d83db632addebe6fe5ad8e9220a10fcf6340f7fca660d87aeedf0f74a142fba6de1f68d849000000001976a914eb0bd5edba389198e73f8efabddfc61666969ff788ac0094357700000000ffffffff0cf3246582f4b1b5fd150b942916c7d5c78e80259cbab1a761a9e4ac3a66e0a70000000041000000",
		},
	}

	for _, test := range testVector {
		t.Run(test.name, func(t *testing.T) {
			tx, err := transaction.NewTransactionFromHex(test.unsignedTx)
			require.NoError(t, err)
			require.NotNil(t, tx)

			// Add the UTXO amount and script (PreviousTx already in unsigned tx)
			prevScript, err := script.NewFromHex(test.SourceTxScript)
			require.NoError(t, err)
			tx.InputIdx(test.index).SetSourceTxOutput(&transaction.TransactionOutput{
				LockingScript: prevScript,
				Satoshis:      test.previousTxSatoshis,
			})

			var actualSigHash []byte
			actualSigHash, err = tx.CalcInputPreimage(uint32(test.index), sighash.All|sighash.ForkID)
			require.NoError(t, err)
			require.Equal(t, test.expectedPreimage, hex.EncodeToString(actualSigHash))
		})
	}
}

func TestTx_CalcInputSignatureHash(t *testing.T) {
	t.Parallel()

	var testVector = []struct {
		name               string
		unsignedTx         string
		index              uint32
		previousTxSatoshis uint64
		SourceTxScript     string
		sigHashType        sighash.Flag
		expectedSigHash    string
	}{
		{
			"1 Input 2 Outputs - SIGHASH_ALL (FORKID)",
			"010000000193a35408b6068499e0d5abd799d3e827d9bfe70c9b75ebe209c91d25072326510000000000ffffffff02404b4c00000000001976a91404ff367be719efa79d76e4416ffb072cd53b208888acde94a905000000001976a91404d03f746652cfcb6cb55119ab473a045137d26588ac00000000",
			0,
			100000000,
			"76a914c0a3c167a28cabb9fbb495affa0761e6e74ac60d88ac",
			sighash.AllForkID,
			"be9a42ef2e2dd7ef02cd631290667292cbbc5018f4e3f6843a8f4c302a2111b1",
		},
		{
			"2 Inputs 3 Outputs - SIGHASH_ALL (FORKID) - Index 0",
			"01000000027e2705da59f7112c7337d79840b56fff582b8f3a0e9df8eb19e282377bebb1bc0100000000ffffffffdebe6fe5ad8e9220a10fcf6340f7fca660d87aeedf0f74a142fba6de1f68d8490000000000ffffffff0300e1f505000000001976a9142987362cf0d21193ce7e7055824baac1ee245d0d88ac00e1f505000000001976a9143ca26faa390248b7a7ac45be53b0e4004ad7952688ac34657fe2000000001976a914eb0bd5edba389198e73f8efabddfc61666969ff788ac00000000",
			0,
			2000000000,
			"76a914eb0bd5edba389198e73f8efabddfc61666969ff788ac",
			sighash.AllForkID,
			"8b15eecfb6d5e727485e19797b5d1829e0630e8b43c806707685238e28a3194c",
		},
		{
			"2 Inputs 3 Outputs - SIGHASH_ALL (FORKID) - Index 1",
			"01000000027e2705da59f7112c7337d79840b56fff582b8f3a0e9df8eb19e282377bebb1bc0100000000ffffffffdebe6fe5ad8e9220a10fcf6340f7fca660d87aeedf0f74a142fba6de1f68d8490000000000ffffffff0300e1f505000000001976a9142987362cf0d21193ce7e7055824baac1ee245d0d88ac00e1f505000000001976a9143ca26faa390248b7a7ac45be53b0e4004ad7952688ac34657fe2000000001976a914eb0bd5edba389198e73f8efabddfc61666969ff788ac00000000",
			1,
			2000000000,
			"76a914eb0bd5edba389198e73f8efabddfc61666969ff788ac",
			sighash.AllForkID,
			"7b72c355a2714a5039d97fbd5eee792099b0eab4bf07d2e5bfcfc3309f81badb",
		},
		{
			"1 Input 2 Outputs - SIGHASH_ALL",
			"010000000193a35408b6068499e0d5abd799d3e827d9bfe70c9b75ebe209c91d25072326510000000000ffffffff02404b4c00000000001976a91404ff367be719efa79d76e4416ffb072cd53b208888acde94a905000000001976a91404d03f746652cfcb6cb55119ab473a045137d26588ac00000000",
			0,
			100000000,
			"76a914c0a3c167a28cabb9fbb495affa0761e6e74ac60d88ac",
			sighash.All,
			"7bd029c36f5a950fe21989893bba45b657b217d62df9b1b49933b9cbe4aff389",
		},
		{
			"2 Inputs 3 Outputs - SIGHASH_ALL - Index 0",
			"01000000027e2705da59f7112c7337d79840b56fff582b8f3a0e9df8eb19e282377bebb1bc0100000000ffffffffdebe6fe5ad8e9220a10fcf6340f7fca660d87aeedf0f74a142fba6de1f68d8490000000000ffffffff0300e1f505000000001976a9142987362cf0d21193ce7e7055824baac1ee245d0d88ac00e1f505000000001976a9143ca26faa390248b7a7ac45be53b0e4004ad7952688ac34657fe2000000001976a914eb0bd5edba389198e73f8efabddfc61666969ff788ac00000000",
			0,
			2000000000,
			"76a914eb0bd5edba389198e73f8efabddfc61666969ff788ac",
			sighash.All,
			"66308491ca2e295f816fcc0cc88b4c46ba3fe58a69654f05833a4917d1102770",
		},
		{
			"2 Inputs 3 Outputs - SIGHASH_ALL - Index 1",
			"01000000027e2705da59f7112c7337d79840b56fff582b8f3a0e9df8eb19e282377bebb1bc0100000000ffffffffdebe6fe5ad8e9220a10fcf6340f7fca660d87aeedf0f74a142fba6de1f68d8490000000000ffffffff0300e1f505000000001976a9142987362cf0d21193ce7e7055824baac1ee245d0d88ac00e1f505000000001976a9143ca26faa390248b7a7ac45be53b0e4004ad7952688ac34657fe2000000001976a914eb0bd5edba389198e73f8efabddfc61666969ff788ac00000000",
			1,
			2000000000,
			"76a914eb0bd5edba389198e73f8efabddfc61666969ff788ac",
			sighash.All,
			"4c8ee5be8b0b4a822284248e3854bda603e6eca5e2db73498759cd3f7c25d329",
		},
	}

	for _, test := range testVector {
		t.Run(test.name, func(t *testing.T) {
			tx, err := transaction.NewTransactionFromHex(test.unsignedTx)
			require.NoError(t, err)
			require.NotNil(t, tx)

			// Add the UTXO amount and script (PreviousTx already in unsigned tx)
			prevScript, err := script.NewFromHex(test.SourceTxScript)
			require.NoError(t, err)
			tx.Inputs[test.index].SetSourceTxOutput(&transaction.TransactionOutput{
				LockingScript: prevScript,
				Satoshis:      test.previousTxSatoshis,
			})

			var actualSigHash []byte
			actualSigHash, err = tx.CalcInputSignatureHash(test.index, test.sigHashType)
			require.NoError(t, err)
			require.Equal(t, test.expectedSigHash, hex.EncodeToString(actualSigHash))
		})
	}
}

func TestTx_CalcInputPreimageLegacy(t *testing.T) {
	t.Parallel()

	var testVector = []struct {
		name               string
		unsignedTx         string
		index              int
		previousTxSatoshis uint64
		SourceTxScript     string
		sigHashType        sighash.Flag
		expectedPreimage   string
	}{
		{
			"1 Input 2 Outputs - SIGHASH_ALL",
			"010000000193a35408b6068499e0d5abd799d3e827d9bfe70c9b75ebe209c91d25072326510000000000ffffffff02404b4c00000000001976a91404ff367be719efa79d76e4416ffb072cd53b208888acde94a905000000001976a91404d03f746652cfcb6cb55119ab473a045137d26588ac00000000",
			0,
			100000000,
			"76a914c0a3c167a28cabb9fbb495affa0761e6e74ac60d88ac",
			sighash.All,
			"010000000193a35408b6068499e0d5abd799d3e827d9bfe70c9b75ebe209c91d2507232651000000001976a914c0a3c167a28cabb9fbb495affa0761e6e74ac60d88acffffffff02404b4c00000000001976a91404ff367be719efa79d76e4416ffb072cd53b208888acde94a905000000001976a91404d03f746652cfcb6cb55119ab473a045137d26588ac0000000001000000",
		},
		{
			"2 Inputs 3 Outputs - SIGHASH_ALL - Index 0",
			"01000000027e2705da59f7112c7337d79840b56fff582b8f3a0e9df8eb19e282377bebb1bc0100000000ffffffffdebe6fe5ad8e9220a10fcf6340f7fca660d87aeedf0f74a142fba6de1f68d8490000000000ffffffff0300e1f505000000001976a9142987362cf0d21193ce7e7055824baac1ee245d0d88ac00e1f505000000001976a9143ca26faa390248b7a7ac45be53b0e4004ad7952688ac34657fe2000000001976a914eb0bd5edba389198e73f8efabddfc61666969ff788ac00000000",
			0,
			2000000000,
			"76a914eb0bd5edba389198e73f8efabddfc61666969ff788ac",
			sighash.All,
			"01000000027e2705da59f7112c7337d79840b56fff582b8f3a0e9df8eb19e282377bebb1bc010000001976a914eb0bd5edba389198e73f8efabddfc61666969ff788acffffffffdebe6fe5ad8e9220a10fcf6340f7fca660d87aeedf0f74a142fba6de1f68d8490000000000ffffffff0300e1f505000000001976a9142987362cf0d21193ce7e7055824baac1ee245d0d88ac00e1f505000000001976a9143ca26faa390248b7a7ac45be53b0e4004ad7952688ac34657fe2000000001976a914eb0bd5edba389198e73f8efabddfc61666969ff788ac0000000001000000",
		},
		{
			"2 Inputs 3 Outputs - SIGHASH_ALL - Index 1",
			"01000000027e2705da59f7112c7337d79840b56fff582b8f3a0e9df8eb19e282377bebb1bc0100000000ffffffffdebe6fe5ad8e9220a10fcf6340f7fca660d87aeedf0f74a142fba6de1f68d8490000000000ffffffff0300e1f505000000001976a9142987362cf0d21193ce7e7055824baac1ee245d0d88ac00e1f505000000001976a9143ca26faa390248b7a7ac45be53b0e4004ad7952688ac34657fe2000000001976a914eb0bd5edba389198e73f8efabddfc61666969ff788ac00000000",
			1,
			2000000000,
			"76a914eb0bd5edba389198e73f8efabddfc61666969ff788ac",
			sighash.All,
			"01000000027e2705da59f7112c7337d79840b56fff582b8f3a0e9df8eb19e282377bebb1bc0100000000ffffffffdebe6fe5ad8e9220a10fcf6340f7fca660d87aeedf0f74a142fba6de1f68d849000000001976a914eb0bd5edba389198e73f8efabddfc61666969ff788acffffffff0300e1f505000000001976a9142987362cf0d21193ce7e7055824baac1ee245d0d88ac00e1f505000000001976a9143ca26faa390248b7a7ac45be53b0e4004ad7952688ac34657fe2000000001976a914eb0bd5edba389198e73f8efabddfc61666969ff788ac0000000001000000",
		},
	}

	for _, test := range testVector {
		t.Run(test.name, func(t *testing.T) {
			tx, err := transaction.NewTransactionFromHex(test.unsignedTx)
			require.NoError(t, err)
			require.NotNil(t, tx)

			// Add the UTXO amount and script (PreviousTx already in unsigned tx)
			prevScript, err := script.NewFromHex(test.SourceTxScript)
			require.NoError(t, err)
			tx.Inputs[test.index].SetSourceTxOutput(&transaction.TransactionOutput{
				LockingScript: prevScript,
				Satoshis:      test.previousTxSatoshis,
			})

			var actualSigHash []byte
			actualSigHash, err = tx.CalcInputPreimageLegacy(uint32(test.index), test.sigHashType)
			require.NoError(t, err)
			require.Equal(t, test.expectedPreimage, hex.EncodeToString(actualSigHash))
		})
	}
}
