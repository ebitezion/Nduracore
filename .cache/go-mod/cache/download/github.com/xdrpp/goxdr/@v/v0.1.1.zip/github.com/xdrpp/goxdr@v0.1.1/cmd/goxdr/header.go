// -*-Go-*-

// Code generated from header.go.in; DO NOT EDIT.
// Generation happens by uncommenting lines marked //UNCOMMENT:.  (The
// comments make it easier to edit the contents of the header string
// as go source code in a syntax-aware editor.)

package main

var header string = `
//
// begin boilerplate
//

// Types passed to the XDR Marshal method implementing the XdrType
// interface.  Pointers to some generated types T already implement
// the interface.  However, since built-in types such as string and
// int32 cannot implement interfaces, each type T has a function
// XDR_T(*T) that returns some type implementing XdrType.  These
// XdrType interfaces also encode limits on string and vector sizes
// and simplify code by collapsing similar cases (e.g., all 32-bit
// numbers are cast to a pointer implementing XdrNum32).
//
// For most XdrType instances, XdrPointer() and XdrValue() provide
// access to the underlying type (which might not implement XdrType),
// with the following exceptions:
//
// * opaque[] (fixed-length arrays of bytes) are returned as
// XdrArrayOpaque (by XdrValue()) or nil (by XdrPointer()).  This is
// because XdrArrayOpaque wraps a byte slice rather than an actual
// array.  One generally doesn't want to pass arrays around; moreover,
// getting a pointer to the actual array provides less information,
// because one can't test for arrays in a type switch without knowing
// the exact length of the array, while one can always dynamically
// test the length of a slice.
//
// * Pointer types, in their XdrRecurse methods, marshal a special
// XdrNum32 type of 0 or 1 to record whether the pointer is nil or the
// value is present.  Since this bool does not exist, XdrPointer()
// returns nil (while XdrValue returns a bool).
//
// * For arrays, XdrValue() passes a slice, rather than the full
// array, so as to avoid copying the array.
type XdrType interface {
	// Return a string describing the name of the type (which will
	// reflect the name of a typedef).
	XdrTypeName() string

	// Return the underlying native representation of an XdrType
	// (e.g., int32 for an XdrInt32).
	XdrValue() interface{}

	// Return a pointer to the underlying native representation of an
	// XdrType (often just the same type as the XdrType, but sometimes
	// not, e.g., for primitive types that can't have methods
	// defined).
	XdrPointer() interface{}

	// Calls x.Marshal(name, v).
	XdrMarshal(XDR, string)
}

// The interface through which values are serialized, printed, etc.
type XDR interface {
	// A function that gets called for each value to be marshalled.
	// The val XdrType argument will be one of the following:
	//
	// * A pointer type implementing XdrNum32 for bool, int, unsigned
	//   int, float, the size of variable-length arrays except string
	//   and opaque, and enums.  In the case of enums, that instance
	//   will just be a pointer to the enum.  In the case of the other
	//   types, it will be a pointer to a defined type that implements
	//   the XdrNum32 interface (since plain go types cannot implement
	//   methods)--e.g., *XdrUint32 for unsigned int.  Variable array
	//   sizes are passed as *XdrSize, which enforces the bound.
	//
	// * A pointer type implementing XdrNum64 for hyper, unsigned
	//   hyper, and double.  These are user-defined versions of int64,
	//   uint64, and float64, called XdrInt64, XdrUint64, and
	//   XdrFloat64, respectively.
	//
	// * An instance of XdrBytes for strings and opaque.
	//   Specifically, strings are passed as XdrString, and
	//   variable-length opaque<> vectors are passed as XdrVecOpaque,
	//   both of which implement XdrVarBytes.
	//
	// * An XdrArrayOpaque containing a slice referencing a byte array
	//   for fixed-length opaque[].  XdrArrayOpaque implements
	//   XdrBytes, but not XdrVarBytes.
	//
	// * An instance of XdrAggregate for structs, unions, and
	//   pointers.  Note that structs and unions are just passed as
	//   pointers to the underlying structures (which all implement
	//   XdrAggregate).  Pointers are passed as an XdrPtr interface
	//   implemented by a defined pointer type (since plain pointers
	//   cannot have methods).
	//
	// Note that the Marshal method is responsible for recursing into
	// XdrAggregate instance by calling the XdrRecurse method.
	// Requiring the Marshal method to recurse manually allows it to
	// refrain from recursing in cases where it needs to special-case
	// the handling of specific types.
	Marshal(name string, val XdrType)

	// This method should just be fmt.Sprintf for XDRs that use name.
	// Those that don't use name can use a trivial method returning ""
	Sprintf(string, ...interface{}) string
}

// The error thrown by marshaling functions when data has a bad value.
type XdrError string
func (v XdrError) Error() string { return string(v) }

// Throws an XdrError.
func XdrPanic(s string, args ...interface{}) {
	panic(XdrError(fmt.Sprintf(s, args...)))
}

// RFC4506 defines bool as equivalent to an enum with values all-caps
// TRUE and FALSE.  For convenience, we represent an XDR bool as a Go
// bool instead, and so define these constants for use in union cases.
// (XDR source files should not use lower-case true and false, as
// these will not work in other languages or with other XDR
// compilers.)
const (
	TRUE = true
	FALSE = false
)

// Unfortunately, you can't cast a bool to an int.  Hence, in
// situations like a union discriminant where we don't know if a type
// is equivalent to bool or not, then, short of using reflection, this
// is how we have to convert to an integer.  Note that this expects
// types int, [u]int32, enum, and bool, rather than pointers to these
// types.
func XdrToI32(i interface{}) int32 {
	switch v := i.(type) {
	case interface{ GetU32() uint32 }:
		return int32(v.GetU32())
	case int32:
		return v
	case uint32:
		return int32(v)
	case int:
		return int32(v)
	case bool:
		if v {
			return 1
		}
		return 0
	}
	panic(XdrError(fmt.Sprintf("XdrToI32: bad type %T", i)))
}

//
// User-defined types used to place methods on basic types
//

// All quantities that should be serialized as 32-bit numbers
// (including bools, enums, union discriminants, the bit saying
// whether or not a pointer is NULL, floats, and vector lenghts) are
// passed to the XDR.Marshal function as a pointer to a defined type
// implementing the XdrNum32 interface.  The one exception is string<>
// and opaque<>, for which it is the job of XDR.Marshal to serialize
// the 32-bit length.
type XdrNum32 interface {
	XdrType
	fmt.Stringer
	fmt.Scanner
	GetU32() uint32
	SetU32(uint32)
}

// Enums additionally provide access to a map of values to names.  You
// generally don't need to invoke the XdrEnumNames() method (since the
// String and Scan methods already access the underlying maps), but
// the presence of this method can be useful to differentiate enums
// from other XdrNum32 types.
type XdrEnum interface {
	XdrNum32
	XdrEnumNames() map[int32]string
}

// All 64-bit numbers (hyper, unsigned hyper, and double) are passed
// to XDR.Marshal as a pointer to a defined type implementing
// XdrNum64.
type XdrNum64 interface {
	XdrType
	fmt.Stringer
	fmt.Scanner
	GetU64() uint64
	SetU64(uint64)
}

// A common interface implemented by XdrString, XdrVecOpaque, and
// XdrArrayOpaque (and hence used to operate on the XdrTypes
// corresponding to value os ftype string<>, opaque<>, and opaque[]).
type XdrBytes interface {
	XdrType
	GetByteSlice() []byte
}

// A common interface implemented by XdrString and XdrVecOpaque, the
// XdrTypes for opaque<> and string<>.  Since XdrVarBytes is a subtype
// of XdrBytes, Marshal functions that want to distinguish between
// opaque<> and opaque[] should first try a type assertion for
// XdrVarBytes (to check for opaque<>) and then if that fails try
// XdrBytes (to check for opaque[]).
type XdrVarBytes interface {
	XdrBytes
	XdrBound() uint32
	SetByteSlice([]byte)
}

// Any struct, union, pointer, or variable-length array type (except
// opaque<> and string<>) is passed to XDR.Marshal as a pointer
// implementing the XdrAggregate interface.  It is the responsibility
// of the XDR.Marshal function to call the XdrRecurse method so as to
// recurse into the data structure.  Placing reponsibility on
// XDR.Marshal for recursing allows a custom XDR to prune the
// serialization at particular types (e.g., for pretty-printing a
// partucular struct in a non-standard way).
type XdrAggregate interface {
	XdrType
	XdrRecurse(XDR, string)
}

// A union type is an XdrAggregate with extra methods for individually
// accessing the tag and active branch.
type XdrUnion interface {
	XdrAggregate
	XdrValid() bool
	XdrValidTags() map[int32]bool // returns nil if there's a default
	XdrUnionTag() XdrNum32
	XdrUnionTagName() string
	XdrUnionBody() XdrType
	XdrUnionBodyName() string
}

// Any pointer type is converted to an XdrType implementing the XdrPtr
// interface for marshaling.  Note XdrPtr is a subtype of
// XdrAggregate.  When a Marshal function does nothing special for
// XdrPtr and treats the XdrPtr like any other XdrAggregate (calling
// XdrRecurse), the Marshal function will then get called one or two
// more times, first with an XdrSize (implementing XdrNum32) to
// marshal the non-NULL bit, and then again with the underlying value
// if the pointer is non-NULL.  An XDR.Marshal function that wants to
// special case pointers can access the present bit from the
// GetPresent and SetPresent methods, then bypass marshaling of the
// bit by calling XdrMarshalValue instead of XdrRecurse.
type XdrPtr interface {
	// Marshals first the present/not-present bool, then if true, the
	// underlying value.
	XdrAggregate

	GetPresent() bool
	SetPresent(bool)

	// If the present/not-present bool is false, this function does
	// nothing.  Otherwise, it marshals just the value, not the bit.
	XdrMarshalValue(XDR, string)
}

// Any vector type is passed as a pointer to a user-defined slice type
// that implements the XdrVec interface.  XdrVec is a superset of
// XdrAggregate, so calling XdrRecurse will recurse to call
// XDR.Marshal first on the size (of type XdrSize), then on each
// element of the slice.  An XDR.Marshal function can manually marshal
// the size and then call XdrMarshalN to marshal n vector elements.
// (When deserializing, it is advisable *not* to call SetVecLen before
// calling XdrMarshalN in case the length is huge and would exhaust
// memory; XdrMarshalN gradually grows the slice size as needed so as
// to throw a premature EOF error if N is larger than the actual input
// data.)
type XdrVec interface {
	XdrAggregate
	XdrBound() uint32
	GetVecLen() uint32
	SetVecLen(uint32)
	XdrMarshalN(XDR, string, uint32)
}

// Any array type is passed as a pointer to a user-defined array
// supporting the XdrArray interface.  This is a subtype of
// XdrAggregate, and so supports recursing to marshal each individual
// array member.
type XdrArray interface {
	XdrAggregate
	XdrArraySize() uint32
}

type XdrTypedef interface {
	XdrType
	XdrUnwrap() XdrType
}

// Unwrap typedefs to obtain the underlying XdrType.
func XdrBaseType(v XdrType) XdrType {
	for {
		t, ok := v.(XdrTypedef)
		if !ok {
			return v
		}
		v = t.XdrUnwrap()
	}
}

// Returns true for A-Z, a-z, 0-9, and _.  (Used by the generated code
// that implements Scanner for enums.)
func XdrSymChar(r rune) bool {
	return (r|0x20 >= 'a' && r|0x20 <= 'z') ||
		(r >= '0' && r <= '9') || r == '_'
}

// An XdrType that marshals as zero bytes, and hence is used to
// represent void argument and return types of functions.
type XdrVoid struct{}
type XdrType_void = *XdrVoid
func (XdrVoid) XdrTypeName() string { return "void" }
func (XdrVoid) XdrValue() interface{} { return nil }
func (XdrVoid) XdrPointer() interface{} { return nil }
func (XdrVoid) XdrMarshal(XDR, string) {}
func XDR_XdrVoid(v *XdrVoid) XdrType_void { return v }

// The XdrType that bool gets turned into for marshaling.
type XdrBool bool
type XdrType_bool = *XdrBool
func (XdrBool) XdrTypeName() string { return "bool" }
func (v XdrBool) String() string { return fmt.Sprintf("%v", v.XdrValue()) }
func (v *XdrBool) Scan(ss fmt.ScanState, r rune) error {
	_, err := fmt.Fscanf(ss, string([]rune{'%', r}), v.XdrPointer())
	return err
}
func (v XdrBool) GetU32() uint32 { if v { return 1 }; return 0 }
func (v *XdrBool) SetU32(nv uint32) {
	switch nv {
	case 0:
		*v = false
	case 1:
		*v = true
	default:
		XdrPanic("bool must be 0 or 1")
	}
}
func (v *XdrBool) XdrPointer() interface{} { return (*bool)(v) }
func (v XdrBool) XdrValue() interface{} { return bool(v) }
func (v *XdrBool) XdrMarshal(x XDR, name string) { x.Marshal(name, v) }
func XDR_bool(v *bool) *XdrBool { return (*XdrBool)(v) }

// The XdrType that int gets converted to for marshaling.
type XdrInt32 int32
type XdrType_int32 = *XdrInt32
func (XdrInt32) XdrTypeName() string { return "int32" }
func (v XdrInt32) String() string { return fmt.Sprintf("%v", v.XdrValue()) }
func (v *XdrInt32) Scan(ss fmt.ScanState, r rune) error {
	_, err := fmt.Fscanf(ss, string([]rune{'%', r}), v.XdrPointer())
	return err
}
func (v XdrInt32) GetU32() uint32 { return uint32(v) }
func (v *XdrInt32) SetU32(nv uint32) { *v = XdrInt32(nv) }
func (v *XdrInt32) XdrPointer() interface{} { return (*int32)(v) }
func (v XdrInt32) XdrValue() interface{} { return int32(v) }
func (v *XdrInt32) XdrMarshal(x XDR, name string) { x.Marshal(name, v) }
func XDR_int32(v *int32) *XdrInt32 { return (*XdrInt32)(v) }

// The XdrType that unsigned int gets converted to for marshaling.
type XdrUint32 uint32
type XdrType_uint32 = *XdrUint32
func (XdrUint32) XdrTypeName() string { return "uint32" }
func (v XdrUint32) String() string { return fmt.Sprintf("%v", v.XdrValue()) }
func (v *XdrUint32) Scan(ss fmt.ScanState, r rune) error {
	_, err := fmt.Fscanf(ss, string([]rune{'%', r}), v.XdrPointer())
	return err
}
func (v XdrUint32) GetU32() uint32 { return uint32(v) }
func (v *XdrUint32) SetU32(nv uint32) { *v = XdrUint32(nv) }
func (v *XdrUint32) XdrPointer() interface{} { return (*uint32)(v) }
func (v XdrUint32) XdrValue() interface{} { return uint32(v) }
func (v *XdrUint32) XdrMarshal(x XDR, name string) { x.Marshal(name, v) }
func XDR_uint32(v *uint32) *XdrUint32 { return (*XdrUint32)(v) }

// The XdrType that float gets converted to for marshaling.
type XdrFloat32 float32
type XdrType_float32 = *XdrFloat32
func (XdrFloat32) XdrTypeName() string { return "float32" }
func (v XdrFloat32) String() string { return fmt.Sprintf("%v", v.XdrValue()) }
func (v *XdrFloat32) Scan(ss fmt.ScanState, r rune) error {
	_, err := fmt.Fscanf(ss, string([]rune{'%', r}), v.XdrPointer())
	return err
}
func (v XdrFloat32) GetU32() uint32 { return math.Float32bits(float32(v)) }
func (v *XdrFloat32) SetU32(nv uint32) {
	*v = XdrFloat32(math.Float32frombits(nv))
}
func (v *XdrFloat32) XdrPointer() interface{} { return (*float32)(v) }
func (v XdrFloat32) XdrValue() interface{} { return float32(v) }
func (v *XdrFloat32) XdrMarshal(x XDR, name string) { x.Marshal(name, v) }
func XDR_float32(v *float32) *XdrFloat32 { return (*XdrFloat32)(v) }

// This XdrType is used to marshal the length of vectors and the
// present/not-present value of pointers.
type XdrSize struct {
	Size uint32
	Bound uint32
}
func (v XdrSize) String() string { return fmt.Sprintf("%v", v.Size) }
func (v *XdrSize) Scan(ss fmt.ScanState, r rune) (err error) {
	defer func() {
		if err == nil {
			err = recover().(error)
		}
	}()
	var nv uint32
	if _, err := fmt.Fscanf(ss, string([]rune{'%', r}), &nv); err != nil {
		return err
	}
	v.SetU32(nv)
	return
}
func (v XdrSize) GetU32() uint32 { return v.Size }
func (v *XdrSize) SetU32(nv uint32) {
	if nv > v.Bound {
		XdrPanic("size %d greater than bound %d", nv, v.Bound)
	} else if int(nv) < 0 {
		XdrPanic("size %d greater than max slice len", nv)
	}
	v.Size = nv
}
func (XdrSize) XdrTypeName() string { return "len" }
func (v *XdrSize) XdrPointer() interface{} { return &v.Size }
func (v XdrSize) XdrValue() interface{} { return v.Size }
func (v *XdrSize) XdrMarshal(x XDR, name string) { x.Marshal(name, v) }
func (v XdrSize) XdrBound() uint32 { return v.Bound }

// The XdrType that hyper gets converted to for marshaling.
type XdrInt64 int64
type XdrType_int64 = *XdrInt64
func (XdrInt64) XdrTypeName() string { return "int64" }
func (v XdrInt64) String() string { return fmt.Sprintf("%v", v.XdrValue()) }
func (v *XdrInt64) Scan(ss fmt.ScanState, r rune) error {
	_, err := fmt.Fscanf(ss, string([]rune{'%', r}), v.XdrPointer())
	return err
}
func (v XdrInt64) GetU64() uint64 { return uint64(v) }
func (v *XdrInt64) SetU64(nv uint64) { *v = XdrInt64(nv) }
func (v *XdrInt64) XdrPointer() interface{} { return (*int64)(v) }
func (v XdrInt64) XdrValue() interface{} { return int64(v) }
func (v *XdrInt64) XdrMarshal(x XDR, name string) { x.Marshal(name, v) }
func XDR_int64(v *int64) *XdrInt64 { return (*XdrInt64)(v) }

// The XdrType that unsigned hyper gets converted to for marshaling.
type XdrUint64 uint64
type XdrType_uint64 = *XdrUint64
func (XdrUint64) XdrTypeName() string { return "uint64" }
func (v XdrUint64) String() string { return fmt.Sprintf("%v", v.XdrValue()) }
func (v *XdrUint64) Scan(ss fmt.ScanState, r rune) error {
	_, err := fmt.Fscanf(ss, string([]rune{'%', r}), v.XdrPointer())
	return err
}
func (v XdrUint64) GetU64() uint64 { return uint64(v) }
func (v *XdrUint64) SetU64(nv uint64) { *v = XdrUint64(nv) }
func (v *XdrUint64) XdrPointer() interface{} { return (*uint64)(v) }
func (v XdrUint64) XdrValue() interface{} { return uint64(v) }
func (v *XdrUint64) XdrMarshal(x XDR, name string) { x.Marshal(name, v) }
func XDR_uint64(v *uint64) *XdrUint64 { return (*XdrUint64)(v) }

// The XdrType that double gets converted to for marshaling.
type XdrFloat64 float64
type XdrType_float64 = *XdrFloat64
func (XdrFloat64) XdrTypeName() string { return "float64" }
func (v XdrFloat64) String() string { return fmt.Sprintf("%v", v.XdrValue()) }
func (v *XdrFloat64) Scan(ss fmt.ScanState, r rune) error {
	_, err := fmt.Fscanf(ss, string([]rune{'%', r}), v.XdrPointer())
	return err
}
func (v XdrFloat64) GetU64() uint64 { return math.Float64bits(float64(v)) }
func (v *XdrFloat64) SetU64(nv uint64) {
	*v = XdrFloat64(math.Float64frombits(nv))
}
func (v *XdrFloat64) XdrPointer() interface{} { return (*float64)(v) }
func (v XdrFloat64) XdrValue() interface{} { return float64(v) }
func (v *XdrFloat64) XdrMarshal(x XDR, name string) { x.Marshal(name, v) }
func XDR_float64(v *float64) *XdrFloat64 { return (*XdrFloat64)(v) }

// The XdrType that strings get converted to for marshaling.
type XdrString struct {
	Str *string
	Bound uint32
}
func (v XdrString) String() string { return fmt.Sprintf("%q", *v.Str) }
func (v XdrString) Scan(ss fmt.ScanState, _ rune) error {
	var s string
	if _, err := fmt.Fscanf(ss, "%q", &s); err != nil {
		return err
	} else if int64(len(s)) > int64(v.Bound) {
		return XdrError(fmt.Sprintf("Cannot store %d bytes in string<%d>",
			len(s), v.Bound))
	}
	*v.Str = s
	return nil
}
func (v XdrString) XdrBound() uint32 { return v.Bound }
func (v XdrString) GetString() string { return *v.Str }
func (v XdrString) SetString(s string) {
	if uint(len(s)) > uint(v.Bound) {
		XdrPanic("Cannot store %d bytes in string<%d>", len(s), v.Bound)
	}
	*v.Str = s
}
func (v XdrString) GetByteSlice() []byte { return ([]byte)(*v.Str) }
func (v XdrString) SetByteSlice(bs []byte) {
	if uint(len(bs)) > uint(v.Bound) {
		XdrPanic("Cannot store %d bytes in string<%d>", len(bs), v.Bound)
	}
	*v.Str = string(bs)
}
func (XdrString) XdrTypeName() string { return "string" }
func (v XdrString) XdrPointer() interface{} { return v.Str }
func (v XdrString) XdrValue() interface{} { return *v.Str }
func (v XdrString) XdrMarshal(x XDR, name string) { x.Marshal(name, v) }

// The XdrType that opaque<> gets converted to for marshaling.
type XdrVecOpaque struct {
	Bytes *[]byte
	Bound uint32
}
func (v XdrVecOpaque) String() string {
	return fmt.Sprintf("%x", []byte(*v.Bytes))
}
func (v XdrVecOpaque) Scan(ss fmt.ScanState, _ rune) error {
	var bs []byte
	_, err := fmt.Fscanf(ss, "%x", &bs)
	if err == nil {
		v.SetByteSlice(bs)
	}
	return err
}
func (v XdrVecOpaque) GetByteSlice() []byte { return *v.Bytes }
func (v XdrVecOpaque) XdrBound() uint32 { return v.Bound }
func (v XdrVecOpaque) SetByteSlice(bs []byte) {
	if uint(len(bs)) > uint(v.Bound) {
		XdrPanic("Cannot store %d bytes in string<%d>", len(bs), v.Bound)
	}
	*v.Bytes = bs
}
func (XdrVecOpaque) XdrTypeName() string { return "opaque<>" }
func (v XdrVecOpaque) XdrPointer() interface{} { return v.Bytes }
func (v XdrVecOpaque) XdrValue() interface{} { return *v.Bytes }
func (v XdrVecOpaque) XdrMarshal(x XDR, name string) { x.Marshal(name, v) }

// Helper function for scanning fix-size opaque arrays.
func XdrArrayOpaqueScan(dest []byte, ss fmt.ScanState, _ rune) error {
	var bs []byte
	_, err := fmt.Fscanf(ss, "%x", &bs)
	if err != nil {
		return err
	} else if len(bs) != len (dest) {
		return XdrError("Wrong number of bytes when scanning opaque[]")
	}
	copy(dest, bs)
	return nil
}

// The interface of XdrTypes of opaque[n] for all n
type XdrArrayOpaque interface {
	XdrBytes
	XdrArraySize() uint32
}


//
// Basic implementations of XDR interface
//

// Back end that renders an XDR data structure as simple text.
// Example:
//
//    XDR_MyType(&myVal).XdrMarshal(&XdrPrint{os.Stdout}, "")
//
type XdrPrint struct {
	Out io.Writer
}

// Generic function that converts any compiled XDR type to a
// multi-line string.  Useful for debugging.
func XdrToString(t XdrType) string {
	out := &strings.Builder{}
	t.XdrMarshal(&XdrPrint{out}, "")
	return out.String()
}

func (xp XdrPrint) Sprintf(f string, args ...interface{}) string {
	return fmt.Sprintf(f, args...)
}

func (xp XdrPrint) Marshal(name string, i XdrType) {
	switch v := i.(type) {
	case fmt.Stringer:
		fmt.Fprintf(xp.Out, "%s: %s\n", name, v.String())
	case XdrPtr:
		fmt.Fprintf(xp.Out, "%s.present: %v\n", name, v.GetPresent())
		v.XdrMarshalValue(xp, fmt.Sprintf("(*%s)", name))
	case XdrVec:
		fmt.Fprintf(xp.Out, "%s.len: %d\n", name, v.GetVecLen())
		v.XdrMarshalN(xp, name, v.GetVecLen())
	case XdrAggregate:
		v.XdrRecurse(xp, name)
	default:
		fmt.Fprintf(xp.Out, "%s: %v\n", name, i)
	}
}

var xdrZerofill [4][]byte = [...][]byte{
	{}, {0,0,0}, {0,0}, {0},
}

func xdrPutBytes(out io.Writer, val []byte) {
	out.Write(val)
	out.Write(xdrZerofill[len(val)&3])
}

func xdrPut32(out io.Writer, val uint32) {
	b := make([]byte, 4)
	binary.BigEndian.PutUint32(b, val)
	out.Write(b)
}

func xdrPut64(out io.Writer, val uint64) {
	b := make([]byte, 8)
	binary.BigEndian.PutUint64(b, val)
	out.Write(b)
}


// XDR that marshals to canonical binary format
type XdrOut struct {
	Out io.Writer
}

func (xp XdrOut) Sprintf(f string, args ...interface{}) string {
	return ""
}

func (xo XdrOut) Marshal(name string, i XdrType) {
	switch v := i.(type) {
	case XdrNum32:
		xdrPut32(xo.Out, v.GetU32())
	case XdrNum64:
		xdrPut64(xo.Out, v.GetU64())
	case XdrString:
		s := v.GetString()
		xdrPut32(xo.Out, uint32(len(s)))
		io.WriteString(xo.Out, s)
		xo.Out.Write(xdrZerofill[len(s)&3])
	case XdrVarBytes:
		xdrPut32(xo.Out, uint32(len(v.GetByteSlice())))
		xdrPutBytes(xo.Out, v.GetByteSlice())
	case XdrBytes:
		xdrPutBytes(xo.Out, v.GetByteSlice())
	case XdrAggregate:
		v.XdrRecurse(xo, name)
	default:
		panic(fmt.Sprintf("XdrOut: unhandled type %T", i))
	}
}

func xdrReadN(in io.Reader, n uint32) []byte {
	var b bytes.Buffer
	if _, err := io.CopyN(&b, in, int64(n)); err != nil {
		XdrPanic(err.Error())
	}
	return b.Bytes()
}

func xdrReadPad(in io.Reader, n uint32) {
	if n & 3 != 0 {
		got := xdrReadN(in, 4-(n&3))
		for _, b := range got {
			if b != 0 {
				XdrPanic("padding contained non-zero bytes")
			}
		}
	}
}

func xdrGet32(in io.Reader) uint32 {
	b := xdrReadN(in, 4)
	return binary.BigEndian.Uint32(b)
}

func xdrGet64(in io.Reader) uint64 {
	b := xdrReadN(in, 8)
	return binary.BigEndian.Uint64(b)
}


// XDR that unmarshals from canonical binary format
type XdrIn struct {
	In io.Reader
}

func (xp XdrIn) Sprintf(f string, args ...interface{}) string {
	return ""
}

func (xi XdrIn) Marshal(name string, i XdrType) {
	switch v := i.(type) {
	case XdrNum32:
		v.SetU32(xdrGet32(xi.In))
	case XdrNum64:
		v.SetU64(xdrGet64(xi.In))
	case XdrVarBytes:
		n := xdrGet32(xi.In)
		v.SetByteSlice(xdrReadN(xi.In, n))
		xdrReadPad(xi.In, n)
	case XdrBytes:
		if _, err := io.ReadFull(xi.In, v.GetByteSlice()); err != nil {
			panic(err)
		}
		xdrReadPad(xi.In, uint32(len(v.GetByteSlice())))
	case XdrAggregate:
		v.XdrRecurse(xi, name)
	}
}


//
// RFC5531 RPC support
//

// Interface for a data structure containing the argument and result
// types of a call.
type XdrProc interface {
	Prog() uint32
	Vers() uint32
	Proc() uint32
	ProgName() string
	VersName() string
	ProcName() string
	GetArg() XdrType
	GetRes() XdrType
}

// Interface for a data structure containing argument and results of a
// procedure plus a way to invoke the procedure on an instance of the
// RPC version.  In other words, Do() actually performs the work of an
// RPC on the server side.
type XdrSrvProc interface {
	XdrProc
	Do()
	SetContext(context.Context)
}

// Interface for an RPC version interface bound to a server
// implementation.  The result of GetProc() can be used to marshal the
// arguments and results as well as actually invoke the function
// (though Do()).
type XdrSrv interface {
	Prog() uint32
	Vers() uint32
	ProgName() string
	VersName() string
	GetProc(uint32) XdrSrvProc
}

// An interface for types that can send remote procedure calls and
// await their reply.
type XdrSendCall interface {
	SendCall(context.Context, XdrProc) error
}

// A catalog of procedures of different RPC programs and versions,
// mostly useful for debugging (e.g., pretty-printing a log of RPC
// messages).  The key to the map is prog<<32|vers.  The function
// returns a new instance of an appropriate XdrProc.
var XdrCatalog = make(map[uint64]func(uint32)XdrProc)

//
// end boilerplate
//
`
