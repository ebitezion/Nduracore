package main

import (
	"fmt"
	"os"
	"path"
	"runtime/debug"

	cmd "github.com/fbsobreira/gotron-sdk/cmd/subcommands"
	// Need this side effect
	_ "github.com/fbsobreira/gotron-sdk/pkg/store"
	"github.com/spf13/cobra"
)

var (
	version string
	commit  string
	builtAt string
	builtBy string
)

func init() {
	if version != "" {
		return
	}
	info, ok := debug.ReadBuildInfo()
	if !ok {
		return
	}
	version = info.Main.Version
	for _, s := range info.Settings {
		switch s.Key {
		case "vcs.revision":
			if len(s.Value) > 7 {
				commit = s.Value[:7]
			} else {
				commit = s.Value
			}
		case "vcs.time":
			builtAt = s.Value
		}
	}
}

func main() {
	// HACK Force usage of go implementation rather than the C based one. Do the right way, see the
	// notes one line 66,67 of https://golang.org/src/net/net.go that say can make the decision at
	// build time.
	_ = os.Setenv("GODEBUG", "netdns=go")
	if commit != "" {
		cmd.VersionWrapDump = version + "-" + commit
	} else {
		cmd.VersionWrapDump = version
	}
	cmd.RootCmd.AddCommand(&cobra.Command{
		Use:   "version",
		Short: "Show version",
		RunE: func(cmd *cobra.Command, args []string) error {
			ver := version
			if commit != "" {
				ver += "-" + commit
			}
			if builtBy != "" || builtAt != "" {
				ver += fmt.Sprintf(" (%v %v)", builtBy, builtAt)
			}
			fmt.Fprintf(os.Stderr, "TronCTL. %v version %v\n",
				path.Base(os.Args[0]), ver)
			os.Exit(0)
			return nil
		},
	})
	cmd.Execute()
}
