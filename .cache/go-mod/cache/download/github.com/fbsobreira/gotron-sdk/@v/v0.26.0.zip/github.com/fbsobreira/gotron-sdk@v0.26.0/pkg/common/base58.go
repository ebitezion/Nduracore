// Package common provides shared utilities for encoding, hashing, and data conversion.
package common

import (
	"crypto/sha256"
	"fmt"

	"github.com/shengdoushi/base58"
)

const addressLength = 20
const prefixMainnet = 0x41

// Encode returns the Base58 encoding of input using the Bitcoin alphabet.
func Encode(input []byte) string {
	return base58.Encode(input, base58.BitcoinAlphabet)
}

// EncodeCheck returns the Base58Check encoding of input (Base58 with a 4-byte SHA-256d checksum).
func EncodeCheck(input []byte) string {
	h256h0 := sha256.New()
	h256h0.Write(input)
	h0 := h256h0.Sum(nil)

	h256h1 := sha256.New()
	h256h1.Write(h0)
	h1 := h256h1.Sum(nil)

	inputCheck := append(append([]byte(nil), input...), h1[:4]...)

	return Encode(inputCheck)
}

// Decode returns the bytes represented by the Base58 string input.
func Decode(input string) ([]byte, error) {
	return base58.Decode(input, base58.BitcoinAlphabet)
}

// DecodeCheck decodes a Base58Check string, validates the checksum and TRON prefix (0x41),
// and returns the decoded bytes (prefix + 20-byte address payload) without the checksum.
func DecodeCheck(input string) ([]byte, error) {
	decodeCheck, err := Decode(input)
	if err != nil {
		return nil, err
	}

	if len(decodeCheck) < 4 {
		return nil, fmt.Errorf("b58 check error")
	}

	// tron address should should have 20 bytes + 4 checksum + 1 Prefix
	if len(decodeCheck) != addressLength+4+1 {
		return nil, fmt.Errorf("invalid address length: %d", len(decodeCheck))
	}

	// check prefix
	if decodeCheck[0] != prefixMainnet {
		return nil, fmt.Errorf("invalid prefix")
	}

	decodeData := decodeCheck[:len(decodeCheck)-4]

	h256h0 := sha256.New()
	h256h0.Write(decodeData)
	h0 := h256h0.Sum(nil)

	h256h1 := sha256.New()
	h256h1.Write(h0)
	h1 := h256h1.Sum(nil)

	if h1[0] == decodeCheck[len(decodeData)] &&
		h1[1] == decodeCheck[len(decodeData)+1] &&
		h1[2] == decodeCheck[len(decodeData)+2] &&
		h1[3] == decodeCheck[len(decodeData)+3] {

		return decodeData, nil
	}

	return nil, fmt.Errorf("b58 check error")
}
