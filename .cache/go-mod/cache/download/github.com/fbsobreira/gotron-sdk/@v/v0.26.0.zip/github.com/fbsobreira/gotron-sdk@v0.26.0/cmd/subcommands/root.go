package cmd

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"os"
	"path"
	"strings"
	"time"

	color "github.com/fatih/color"
	"github.com/fbsobreira/gotron-sdk/pkg/client"
	"github.com/fbsobreira/gotron-sdk/pkg/client/transaction"
	c "github.com/fbsobreira/gotron-sdk/pkg/common"
	"github.com/fbsobreira/gotron-sdk/pkg/store"
	"github.com/spf13/cobra"
	"github.com/spf13/cobra/doc"
	"golang.org/x/term"
)

var (
	addr                   tronAddress
	signer                 string
	signerAddress          tronAddress
	verbose                bool
	dryRun                 bool
	noWait                 bool
	useLedgerWallet        bool
	noPrettyOutput         bool
	userProvidesPassphrase bool
	passphraseFilePath     string
	defaultKeystoreDir     string
	node                   string
	givenFilePath          string
	timeout                uint32
	withTLS                bool
	apiKey                 string
	conn                   *client.GrpcClient
	// RootCmd is single entry point of the CLI
	RootCmd = &cobra.Command{
		Use:          "tronctl",
		Short:        "Tron Blockchain Controller",
		SilenceUsage: true,
		PersistentPreRunE: func(cmd *cobra.Command, args []string) error {
			// sync flag values into runtime
			rt.Verbose = verbose
			rt.Node = node
			rt.APIKey = apiKey
			rt.WithTLS = withTLS
			rt.NoPrettyOutput = noPrettyOutput
			rt.NoWait = noWait
			rt.DryRun = dryRun
			rt.Timeout = timeout
			rt.UseLedgerWallet = useLedgerWallet
			rt.GivenFilePath = givenFilePath
			rt.DefaultKeystoreDir = defaultKeystoreDir

			rt.loadDotEnv()
			rt.setupVerbose()
			signer = rt.applyEnvOverrides(config.Node, signer, withTLS)

			if err := rt.setupNetwork(); err != nil {
				return err
			}
			// sync back to legacy globals
			conn = rt.Conn

			if err := rt.setupSigner(signer); err != nil {
				return err
			}
			signerAddress = rt.SignerAddress

			var err error
			rt.Passphrase, err = getPassphrase()
			if err != nil {
				return err
			}
			passphrase = rt.Passphrase

			rt.setupKeystore()

			return nil
		},
		Long: fmt.Sprintf(`
CLI interface to Tron blockchain

%s`, g("type 'tronctl --help' for details")),
		RunE: func(cmd *cobra.Command, args []string) error {
			return cmd.Help()
		},
	}
)

func init() {
	initConfig()

	vS := "dump out debug information, same as env var GOTRON_SDK_DEBUG=true"
	RootCmd.PersistentFlags().BoolVarP(&verbose, "verbose", "v", config.Verbose, vS)
	RootCmd.PersistentFlags().StringVarP(&signer, "signer", "s", "", "<signer>")
	RootCmd.PersistentFlags().StringVarP(&node, "node", "n", config.Node, "<host>")
	RootCmd.PersistentFlags().StringVarP(&apiKey, "apiKey", "k", config.APIKey, "<api-key>")
	RootCmd.PersistentFlags().BoolVar(&withTLS, "withTLS", config.WithTLS, "<bool>")
	RootCmd.PersistentFlags().BoolVar(
		&noPrettyOutput, "no-pretty", config.NoPretty, "Disable pretty print JSON outputs",
	)
	RootCmd.PersistentFlags().BoolVar(&noWait, "no-wait", false, "do not wait for TX confirmation")
	RootCmd.Flags().BoolVar(&dryRun, "dry-run", false, "do not send signed transaction")
	RootCmd.Flags().Uint32Var(&timeout, "timeout", config.Timeout, "set timeout in seconds. Set to 0 to not wait for confirm")

	RootCmd.PersistentFlags().BoolVarP(&useLedgerWallet, "ledger", "e", config.Ledger, "Use ledger hardware wallet")
	RootCmd.PersistentFlags().StringVar(&givenFilePath, "file", "", "Path to file for given command when applicable")

	// Password
	RootCmd.PersistentFlags().BoolVar(&userProvidesPassphrase, "passphrase", false, ppPrompt)
	RootCmd.PersistentFlags().StringVar(&passphraseFilePath, "passphrase-file", "", "path to a file containing the passphrase")
	RootCmd.PersistentFlags().StringVar(&defaultKeystoreDir, "ks-dir", "", "path to keystore")

	RootCmd.AddCommand(&cobra.Command{
		Use:   "docs",
		Short: fmt.Sprintf("Generate docs to a local %s directory", tronctlDocsDir),
		RunE: func(cmd *cobra.Command, args []string) error {
			cwd, _ := os.Getwd()
			docDir := path.Join(cwd, tronctlDocsDir)
			err := os.Mkdir(docDir, 0700)
			if err != nil && !os.IsExist(err) {
				return fmt.Errorf("could not create %s directory: %v", tronctlDocsDir, err)
			}
			err = doc.GenMarkdownTree(RootCmd, docDir)
			return err
		},
	})
}

var (
	// VersionWrapDump meant to be set from main.go
	VersionWrapDump = ""
	versionLink     = "https://api.github.com/repos/fbsobreira/gotron-sdk/releases/latest"
	versionTagLink  = "https://api.github.com/repos/fbsobreira/gotron-sdk/git/ref/tags/"
)

// GitHubReleaseAssets json struct
type GitHubReleaseAssets struct {
	ID   json.Number `json:"id"`
	Name string      `json:"name"`
	Size json.Number `json:"size"`
	URL  string      `json:"browser_download_url"`
}

// GitHubRelease json struct
type GitHubRelease struct {
	Prerelease      bool                  `json:"prerelease"`
	TagName         string                `json:"tag_name"`
	TargetCommitish string                `json:"target_commitish"`
	CreatedAt       time.Time             `json:"created_at"`
	Assets          []GitHubReleaseAssets `json:"assets"`
}

// GitHubTag json struct
type GitHubTag struct {
	Ref    string `json:"ref"`
	NodeID string `json:"node_id"`
	URL    string `json:"url"`
	DATA   struct {
		SHA string `json:"sha"`
	} `json:"object"`
}

func getGitVersion() (string, error) {
	resp, err := http.Get(versionLink)
	if err != nil {
		return "", err
	}

	if resp != nil {
		defer func() { _ = resp.Body.Close() }()
	}
	// if error, no op
	if resp != nil && resp.StatusCode == 200 {
		buf := new(bytes.Buffer)
		_, err = buf.ReadFrom(resp.Body)
		if err != nil {
			return "", err
		}
		release := &GitHubRelease{}
		if err := json.Unmarshal(buf.Bytes(), release); err != nil {
			return "", err
		}

		respTag, err := http.Get(versionTagLink + release.TagName)
		if err != nil || respTag == nil {
			return "", fmt.Errorf("failed to fetch tag: %w", err)
		}
		defer func() { _ = respTag.Body.Close() }()
		if respTag.StatusCode == 200 {
			buf.Reset()
			_, err := buf.ReadFrom(respTag.Body)
			if err != nil {
				return "", err
			}

			releaseTag := &GitHubTag{}
			if err := json.Unmarshal(buf.Bytes(), releaseTag); err != nil {
				return "", err
			}
			commit := strings.Split(VersionWrapDump, "-")

			if releaseTag.DATA.SHA[:8] != commit[1] {
				warnMsg := fmt.Sprintf("Warning: Using outdated version. Redownload to upgrade to %s\n", release.TagName)
				fmt.Fprintf(os.Stderr, "%s", color.RedString(warnMsg))
				return release.TagName, fmt.Errorf("%s", warnMsg)
			}
			return release.TagName, nil
		}
	}
	return "", fmt.Errorf("could not fetch version")
}

// Execute kicks off the tronctl CLI
func Execute() {
	RootCmd.SilenceErrors = true
	if err := RootCmd.Execute(); err != nil {
		if tag, errGit := getGitVersion(); errGit == nil {
			VersionWrapDump += ":" + tag
		}
		errMsg := fmt.Errorf("commit: %s, error: %w", VersionWrapDump, err).Error()
		fmt.Fprintf(os.Stderr, "%s\n", errMsg)
		fmt.Fprintf(os.Stderr, "try adding a `--help` flag\n")
		os.Exit(1)
	}
}

func validateAddress(cmd *cobra.Command, args []string) error {
	// Check if input valid one address
	var err error
	addr, err = findAddress(args[0])
	return err
}

func findAddress(value string) (tronAddress, error) {
	// Check if input valid one address
	address := tronAddress{}
	if err := address.Set(value); err != nil {
		// Check if input is valid account name
		if acc, err := store.AddressFromAccountName(value); err == nil {
			return tronAddress{acc}, nil
		}
		return address, fmt.Errorf("Invalid address/Invalid account name: %s", value)
	}
	return address, nil
}

func opts(ctlr *transaction.Controller) {
	if rt.DryRun {
		ctlr.Behavior.DryRun = true
	}
	if rt.UseLedgerWallet {
		ctlr.Behavior.SigningImpl = transaction.Ledger
	}
	if rt.NoWait {
		ctlr.Behavior.ConfirmationWaitTime = 0
	} else if rt.Timeout > 0 {
		ctlr.Behavior.ConfirmationWaitTime = rt.Timeout
	}
}

// getPassphrase fetches the correct passphrase depending on if a file is available to
// read from or if the user wants to enter in their own passphrase. Otherwise, just use
// the default passphrase. No confirmation of passphrase
func getPassphrase() (string, error) {
	if passphraseFilePath != "" {
		if _, err := os.Stat(passphraseFilePath); os.IsNotExist(err) {
			return "", fmt.Errorf("passphrase file not found at `%s`", passphraseFilePath)
		}
		dat, err := os.ReadFile(passphraseFilePath)
		if err != nil {
			return "", err
		}
		pw := strings.TrimSuffix(string(dat), "\n")
		return pw, nil
	} else if userProvidesPassphrase {
		fmt.Println("Enter passphrase:")
		pass, err := term.ReadPassword(int(os.Stdin.Fd()))
		if err != nil {
			return "", err
		}
		return string(pass), nil
	} else {
		return c.DefaultPassphrase, nil
	}
}

// getPassphraseWithConfirm fetches the correct passphrase depending on if a file is
// available to read from or if the user wants to enter in their own passphrase.
// Otherwise, just use the default passphrase. Passphrase requires a confirmation
func getPassphraseWithConfirm() (string, error) {
	if passphraseFilePath != "" {
		if _, err := os.Stat(passphraseFilePath); os.IsNotExist(err) {
			return "", fmt.Errorf("passphrase file not found at `%s`", passphraseFilePath)
		}
		dat, err := os.ReadFile(passphraseFilePath)
		if err != nil {
			return "", err
		}
		pw := strings.TrimSuffix(string(dat), "\n")
		return pw, nil
	} else if userProvidesPassphrase {
		fmt.Println("Enter passphrase:")
		pass, err := term.ReadPassword(int(os.Stdin.Fd()))
		if err != nil {
			return "", err
		}
		fmt.Println("Repeat the passphrase:")
		repeatPass, err := term.ReadPassword(int(os.Stdin.Fd()))
		if err != nil {
			return "", err
		}
		if string(repeatPass) != string(pass) {
			return "", errors.New("passphrase does not match")
		}
		fmt.Println("") // provide feedback when passphrase is entered.
		return string(repeatPass), nil
	} else {
		return c.DefaultPassphrase, nil
	}
}
