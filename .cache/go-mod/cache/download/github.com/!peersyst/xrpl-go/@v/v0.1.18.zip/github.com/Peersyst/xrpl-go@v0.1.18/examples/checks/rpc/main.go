package main

import (
	"fmt"

	"github.com/Peersyst/xrpl-go/pkg/crypto"
	"github.com/Peersyst/xrpl-go/xrpl/faucet"
	"github.com/Peersyst/xrpl-go/xrpl/ledger-entry-types"
	"github.com/Peersyst/xrpl-go/xrpl/rpc"
	"github.com/Peersyst/xrpl-go/xrpl/transaction"
	"github.com/Peersyst/xrpl-go/xrpl/transaction/types"
	"github.com/Peersyst/xrpl-go/xrpl/wallet"
)

func main() {
	cfg, err := rpc.NewClientConfig(
		"https://s.altnet.rippletest.net:51234/",
		rpc.WithFaucetProvider(faucet.NewTestnetFaucetProvider()),
	)
	if err != nil {
		panic(err)
	}

	client := rpc.NewClient(cfg)

	w, err := wallet.New(crypto.ED25519())
	if err != nil {
		fmt.Println(err)
		return
	}

	receiverWallet, err := wallet.New(crypto.ED25519())
	if err != nil {
		fmt.Println(err)
		return
	}

	fmt.Println("⏳ Setting up wallets...")
	if err := client.FundWallet(&w); err != nil {
		fmt.Println(err)
		return
	}
	fmt.Println("💸 Sender wallet funded!")

	if err := client.FundWallet(&receiverWallet); err != nil {
		fmt.Println(err)
		return
	}

	fmt.Println("💸 Receiver wallet funded!")
	fmt.Println()

	fmt.Println("✅ Wallets setup complete!")
	fmt.Println("💳 Sender wallet:", w.ClassicAddress)
	fmt.Println("💳 Receiver wallet:", receiverWallet.ClassicAddress)
	fmt.Println()

	fmt.Println("⏳ Creating check...")
	cc := &transaction.CheckCreate{
		BaseTx: transaction.BaseTx{
			Account: w.GetAddress(),
		},
		Destination: receiverWallet.GetAddress(),
		SendMax:     types.XRPCurrencyAmount(1000000),
		InvoiceID:   "46060241FABCF692D4D934BA2A6C4427CD4279083E38C77CBE642243E43BE291",
	}

	flatCc := cc.Flatten()

	if err := client.Autofill(&flatCc); err != nil {
		fmt.Println(err)
		return
	}

	blob, _, err := w.Sign(flatCc)
	if err != nil {
		fmt.Println(err)
		return
	}

	res, err := client.SubmitTxBlobAndWait(blob, false)
	if err != nil {
		fmt.Println(err)
		return
	}

	if !res.Validated {
		fmt.Println("❌ Check creation failed!")
		fmt.Println("Try again!")
		fmt.Println()
		return
	}

	fmt.Println("✅ Check created!")
	fmt.Printf("🌐 Hash: %s\n", res.Hash.String())
	fmt.Println()

	meta := res.Meta.AsTxObjMeta()

	var checkID string

	affectedNodes := meta.AffectedNodes

	for _, affectedNode := range affectedNodes {
		if affectedNode.CreatedNode == nil {
			fmt.Println("❌ Node is not of type map[string]any")
			return
		}

		if affectedNode.CreatedNode.LedgerEntryType == ledger.CheckEntry {
			checkID = affectedNode.CreatedNode.LedgerIndex
		}
	}

	if checkID == "" {
		fmt.Println("Check not found")
		return
	}

	fmt.Println("⏳ Cashing out check...")
	checkCash := &transaction.CheckCash{
		BaseTx: transaction.BaseTx{
			Account: receiverWallet.GetAddress(),
		},
		CheckID: types.Hash256(checkID),
		Amount:  types.XRPCurrencyAmount(1000000),
	}

	flatCheckCash := checkCash.Flatten()

	if err := client.Autofill(&flatCheckCash); err != nil {
		fmt.Println(err)
		return
	}

	blob, _, err = receiverWallet.Sign(flatCheckCash)
	if err != nil {
		fmt.Println(err)
		return
	}

	res, err = client.SubmitTxBlobAndWait(blob, false)
	if err != nil {
		fmt.Println(err)
		return
	}

	fmt.Println("✅ Check cashed out!")
	fmt.Printf("🌐 Hash: %s\n", res.Hash.String())
	fmt.Println()
}
